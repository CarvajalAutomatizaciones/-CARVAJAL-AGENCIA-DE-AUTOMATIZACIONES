document.querySelectorAll(".plan-tab").forEach(button => {
  button.addEventListener("click", () => {
    if (button.classList.contains("locked")) return;
    document.querySelectorAll(".plan-tab").forEach(b => {
      b.classList.remove("active");
      b.setAttribute("aria-selected", "false");
    });
    document.querySelectorAll(".plan-panel").forEach(p => {
      p.hidden = true;
      p.classList.remove("active");
    });
    button.classList.add("active");
    button.setAttribute("aria-selected", "true");
    const panel = document.getElementById(button.dataset.plan);
    panel.hidden = false;
    panel.classList.add("active");
  });
});