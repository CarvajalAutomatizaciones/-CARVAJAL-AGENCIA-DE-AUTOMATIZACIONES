# Carvajal Agencia de Automatizaciones

Landing page inicial, elegante y responsive, para presentar los servicios de automatización empresarial.

## Archivos
- `index.html` — página principal
- `styles.css` — diseño
- `script.js` — pestañas de planes

## Verla inmediatamente en tu PC
Abre `index.html` directamente en el navegador.

## Verla desde otros dispositivos de tu red
Con Python instalado, abre una terminal dentro de esta carpeta y ejecuta:

`python -m http.server 8080 --bind 0.0.0.0`

Luego, desde otro dispositivo conectado a la misma red, entra a:

`http://IP-DE-TU-PC:8080`

Para verla públicamente en Internet necesitaremos posteriormente desplegarla en un hosting o usar un túnel seguro. No hace falta hacerlo todavía.

## Datos actuales
WhatsApp: +591 62450812
Correo comercial: cagenciauto@gmail.com
Correo de privacidad: mijailcar555@gmail.com

El plan Starter está habilitado. Business y Pro aparecen bloqueados como "Próximamente".
