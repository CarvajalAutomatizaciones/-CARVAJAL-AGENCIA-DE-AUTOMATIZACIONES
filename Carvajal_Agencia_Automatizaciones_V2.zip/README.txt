CARVAJAL AGENCIA DE AUTOMATIZACIONES — V2
Esta versión no depende de archivos CSS/JS externos: todo el diseño está dentro de index.html.
Por eso puedes abrir index.html directamente con doble clic y debería verse con diseño completo.

Datos configurados:
WhatsApp: +591 62450812
Comercial: cagenciauto@gmail.com
Privacidad: mijailcar555@gmail.com

Nota: para publicar en Internet posteriormente puedes subir index.html a un hosting estático.
